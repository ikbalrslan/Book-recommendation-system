from cosineSim import cosineSimilarity
from collections import OrderedDict
from correlationSim import correlationSimilarity
from adjustedSim import adjustedCosSimilarity
import numpy as np
from matplotlib.pylab import plt #load plot library
# indicate the output of plotting function is printed to the notebook



"""
Calculates kNN and weighted kNN calculations for books as predicted ratings of books
"""
def kNN(trainDataDict, testDataDict, trainBookDict, threshold, k_variable, similarityFunc):
    simDict = {} # CosineDict for keeping each test user's cossine similarity calculations
    total_Prediction = 0

    #print("test user count: " + str(len(testDataDict.keys())))
    #print("-------------------------------------------")

    ratingSumofSameBook = 0
    sameBookCount = 0
    knnList = []
    weightedKnnList = []
    
    allMAE = 0 #sum of all user errors results
    allWeightedMae = 0 #sum of all users weighted error results
    
    predictedUserCount = 0
    for i in testDataDict.keys():

        sumOfAbsOfBook = 0
        weightedSumOfAbsOfBook = 0
        predictCountOfUser = 0

        simDict[i] = {}
        if(similarityFunc == "cos"):
            """
            calculates cosine similarities for each test user with train users
            """
            simDict[i] = cosineSimilarity(testDataDict[i], trainDataDict, trainBookDict)
        elif(similarityFunc == "corr"):
            """
            lowest mae result from splitted test data by correlation similarity.
            calculates correlation similarities for each test user with train users
            """
            simDict[i] = correlationSimilarity(testDataDict[i], trainDataDict, trainBookDict)
        elif(similarityFunc == "adj"):
            """
            highest mae result from splitted test data by adjusted cosine similarity.
            calculates adjusted cosine similarities for each test user with train users
            """
            simDict[i] = adjustedCosSimilarity(testDataDict[i], trainDataDict, trainBookDict)

        simDict[i] = OrderedDict(sorted(simDict[i].items(), key=lambda t: t[1]))  #ordered dict by values - cosineSimilarities
        topKTrainKey = list(simDict[i].keys())[-k_variable:] # first k_variable of cosine keys
        topKSimilarity = list(simDict[i].values())[-k_variable:] # first k_variable of cosine similarities
        """
        1/similarity**(P)
        """
        simValueOfBook = 0
        for j in testDataDict[i]:
            try:
                bookCount = len(trainBookDict[j].values())
            except:
                bookCount = 0

            if  bookCount >= threshold:
                for k in range(len(topKTrainKey)):
                    if j in trainDataDict[topKTrainKey[k]]:
                        sameBookCount += 1 #count of same book at the topKTrain user
                        ratingSumofSameBook += trainDataDict[topKTrainKey[k]][j]
                        simValueOfBook = topKSimilarity[k]
                if(ratingSumofSameBook != 0):
                    kNNOfBook = (ratingSumofSameBook / sameBookCount)
                    if(simValueOfBook == 0):
                        weightedKNNOfBook = 0
                    else:
                        """
                        weighted kNN value is found with multiplying squre of similarity value with kNN value.
                        Normally, scaler of weighted kNN value must be choosen by 1 / ((distance) ** 2).
                        but our similarity values are scaling between 0 to 1. So if this weight formula was used directly;
                        users with high distances acts like very similar each other, but they don't. 
                        I changed formula with (distance ** 2) and it works very well ! 
                        """
                        try:
                            weightedKNNOfBook = ((simValueOfBook) ** 2) * kNNOfBook
                        except:
                            weightedKNNOfBook = 0

                    #print(simValueOfBook, kNNOfBook)
                else:
                    kNNOfBook = 0
                    weightedKNNOfBook = 0
            else:
                meanOfGuess = userMeanRating(testDataDict[i])
                # user rating mean used for non-database book
                #print("mean", userMeanRating(testDataDict[i]))

                kNNOfBook = meanOfGuess
                weightedKNNOfBook = meanOfGuess

            total_Prediction += 1
            predictCountOfUser += 1

            sumOfAbsOfBook += abs(testDataDict[i][j] - kNNOfBook)
            weightedSumOfAbsOfBook += abs(testDataDict[i][j] - weightedKNNOfBook)

            knnList.append(kNNOfBook)
            weightedKnnList.append(weightedKNNOfBook)
            ratingSumofSameBook = 0
            sameBookCount = 0

        if predictCountOfUser > 0:
            predictedUserCount += 1

        if sumOfAbsOfBook == 0 or predictCountOfUser == 0:
            mae = 0
        else:
            mae = sumOfAbsOfBook / predictCountOfUser
        if weightedSumOfAbsOfBook == 0 or predictCountOfUser == 0:
            weightedMae = 0
        else:
            weightedMae = weightedSumOfAbsOfBook / predictCountOfUser



        #print("USER: " + str(i))
        #print(str(i) + " mae of user: " + str(mae))
        #print(str(i) + " weightedMae of user: " + str(weightedMae))
        allMAE += mae
        allWeightedMae += weightedMae

        #print("--------------------------------------------")



    meanOfMaes = allMAE / predictedUserCount
    meanOfWeightedMaes = allWeightedMae / predictedUserCount

    #printMaes(meanOfMaes, meanOfWeightedMaes, total_Prediction)

    return [meanOfMaes,meanOfWeightedMaes]

def userMeanRating(user):
    return sum(user.values()) / len(user.values())

def printMaes(meanOfMaes, meanOfWeightedMaes, total_Prediction):
    # print(sorted(knnList))
    print("total prediction: " + str(total_Prediction))
    print("MAE: " + str(meanOfMaes))
    print("WEIGHTED MAE: " + str(meanOfWeightedMaes))

def drawPlotOfAllScores(corr,wCorr,adj,wAdj,cos,Wcos):
    A = cos
    B = Wcos
    C = corr
    D = wCorr
    E = adj
    F = wAdj

    plt.rcParams['figure.figsize'] = (10, 6)

    plt.plot(A, label="Non-Weighted Cosine")
    plt.plot(B, label="Weighted Cosine")
    plt.plot(C, label="Non-Weighted Correlation")
    plt.plot(D, label="Weighted Correlation")
    plt.plot(E, label="Non-Weighted Adjusted Cosine")
    plt.plot(F, label="Weighted Adjusted Cosine")
    # Add legend
    # Place a legend to the right of this smaller subplot.
    plt.legend(bbox_to_anchor=(1.05, 1), loc=2, borderaxespad=0.)
    # Add title and x, y labels
    plt.title("K-Fold CV", fontsize=16)
    plt.xlabel("k value")
    plt.ylabel("MAE Score")
    plt.savefig('myfig.png', bbox_inches="tight")
    plt.show()