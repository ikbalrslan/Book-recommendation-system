import pandas as pd
from sklearn import datasets, linear_model
from sklearn.model_selection import train_test_split

"""
Created on Mon Oct 22 15:29:44 2018
@author: ikbal
"""


def readFiles(fileUser, fileBook, fileRating ,testFile):
    testRatingsFile = pd.read_csv(testFile, sep=';', error_bad_lines=False, encoding="latin-1", index_col=False,
                        warn_bad_lines=False, low_memory=False)
    
    testRatingsFile.columns = ['userID', 'ISBN', 'bookRating']
    
    books = pd.read_csv(fileBook, sep=';', error_bad_lines=False, encoding="latin-1", index_col=False,
                        warn_bad_lines=False, low_memory=False)
    books.columns = ['ISBN', 'bookTitle', 'bookAuthor', 'yearOfPublication', 'publisher', 'imageUrlS', 'imageUrlM',
                     'imageUrlL']

    users = pd.read_csv(fileUser, sep=';', error_bad_lines=False, encoding="latin-1", warn_bad_lines=False,
                        low_memory=False)
    users.columns = ['userID', 'Location', 'Age']
    filtered_user = users[users['Location'].str.contains("canada|usa") == True]

    ratings = pd.read_csv(fileRating, sep=';', error_bad_lines=False, encoding="latin-1", warn_bad_lines=False,
                          low_memory=False)
    ratings.columns = ['userID', 'ISBN', 'bookRating']

    result = pd.merge(books, ratings, on='ISBN')
    rating_filter = pd.merge(result, filtered_user, on='userID')

    testResult = pd.merge(books,testRatingsFile, on='ISBN')
    test_rating_filter = pd.merge(testResult, filtered_user,on='userID')

    sorted_rating_filter = rating_filter.sort_values(by=['userID'])
    sorted_test_rating_filter = test_rating_filter.sort_values(by=['userID'])

    train, test = train_test_split(sorted_rating_filter, test_size=0.3, shuffle=True)

    print("size: ", len(sorted_test_rating_filter))

    return [sorted_rating_filter,sorted_test_rating_filter]
    #return [train,test]