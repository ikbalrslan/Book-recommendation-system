from collections import defaultdict

"""
Created on Mon Oct 22 15:29:44 2018
@author: ikbal
"""



def meanOfUserRatings(user):
    sumOfBookRatings = sum(user.values())
    mean = sumOfBookRatings / len(user.values())
    return mean

"""
adjustedCosine similarity of test user with train user
"""
def adjustedCosSimilarity(testUserBooks, trainDataDict, trainBookDict):

    userAboveOfSim = defaultdict(int)
    userBelowOfSim = defaultdict(int)

    trainBookSum = 0
    for i in testUserBooks.keys():
        if i in trainBookDict.keys():
            for j in trainBookDict[i].keys():
                #print(j, testUserBooks[i], meanOfBookRating(trainBookDict[i]), trainDataDict[j][i], meanOfBookRating(trainBookDict[i]))
                # over calculations
                userAboveOfSim[j] += (testUserBooks[i] - meanOfUserRatings(testUserBooks)) * (trainDataDict[j][i] - meanOfUserRatings(trainDataDict[j]))
                userBelowOfSim[j] += ((trainDataDict[j][i] - meanOfUserRatings(trainDataDict[j])) ** 2)

    """
    test user below calculations of similarity
    """
    testBookSum = 0
    for i in testUserBooks.keys():
        if i in trainBookDict.keys():
            testBookSum += ((testUserBooks[i] - meanOfUserRatings(testUserBooks)) ** 2)
    rootOfTest = testBookSum ** (.5)

    for i in userBelowOfSim.keys():
        userBelowOfSim[i] = (userBelowOfSim[i] ** (.5))

    """
    result of similarity correlation formula
    """
    adjCosDict = defaultdict(int)
    for i in userAboveOfSim.keys():
        if (userAboveOfSim[i] != 0):
            adjCosineSimilarity = (userAboveOfSim[i] / (rootOfTest * userBelowOfSim[i]))
        else:
            adjCosineSimilarity = 0
        adjCosDict[i] = adjCosineSimilarity

    return adjCosDict