from collections import defaultdict

"""
Created on Mon Oct 22 15:29:44 2018
@author: ikbal
"""

"""
cosine similarity of test user with train users
"""
def cosineSimilarity(testUserBooks, trainDataDict, trainBookDict):

    userDotOfCosines = defaultdict(int) #initial zero values

    for i in testUserBooks.keys(): #each book of test user
        if i in trainBookDict.keys(): #if book in book data
            for j in trainBookDict[i].keys(): #each user that read the current book
                userDotOfCosines[j] += (testUserBooks[i] * trainBookDict[i][j]) #add this user to dot dict with value
                #print(i,testUserBooks[i], trainBookDict[i])

    cosineDictOfTest = defaultdict(int)

    for i in userDotOfCosines.keys():
        trainSum = 0
        testSum = 0

        for j in trainDataDict[i]:
            # print(trainUser[j])
            trainSum += trainDataDict[i][j] ** 2
        # print("-----------------------------------------------------------------")
        for j in testUserBooks.keys():
            # print(testUser[k])
            testSum += testUserBooks[j] ** 2

        normTrain = trainSum ** (.5) #find norm of model user
        normTest = testSum ** (.5) #find norm of test user

        if (userDotOfCosines[i] != 0):
            cossineSimilarity = (userDotOfCosines[i] / (normTrain * normTest))
        else:
            cossineSimilarity = 0

        cosineDictOfTest[i] = cossineSimilarity

    """
    for i in trainDataDict.keys():
        if i not in cosineDict.keys():
            cosineDict[i] = 0
    """
    return cosineDictOfTest
