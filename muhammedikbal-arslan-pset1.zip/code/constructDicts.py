
"""
this function takes 2 parameter as train data and test data
and keeps those datas in to dictinaries names as trainDataDict and testDataDict
"""


def constructDictMatrices(trainDataFrame, testDataFrame):
    # combineDict = trainDataFrame.to_dict('index') #turn dataframe to dict
    trainCombinedUserIDList = trainDataFrame['userID'].tolist()
    trainCombinedISBNList = trainDataFrame['ISBN'].tolist()
    trainCombinedRatingList = trainDataFrame['bookRating'].tolist()

    # combineDict = testDataFrame.to_dict('index') #turn dataframe to dict
    testCombinedUserIDList = testDataFrame['userID'].tolist()
    testCombinedISBNList = testDataFrame['ISBN'].tolist()
    testCombinedRatingList = testDataFrame['bookRating'].tolist()

    # print("size combinedUserIDList " + str(len(trainCombinedUserIDList)))
    # print("size combinedISBNList " + str(len(trainCombinedISBNList)))
    # print("size combinedRatingList " + str(len(trainCombinedRatingList)))

    trainDataDict = {}
    trainBookDict = {}
    for i in range(len(trainCombinedUserIDList)):
        if (trainCombinedUserIDList[i] not in trainDataDict):
            trainDataDict[trainCombinedUserIDList[i]] = {}
        trainDataDict[trainCombinedUserIDList[i]][trainCombinedISBNList[i]] = trainCombinedRatingList[i]

        if (trainCombinedISBNList[i] not in trainBookDict):
            trainBookDict[trainCombinedISBNList[i]] = {}
        trainBookDict[trainCombinedISBNList[i]][trainCombinedUserIDList[i]] = trainCombinedRatingList[
            i]  # print(trainCombinedISBNList[i], trainBookDict[trainCombinedISBNList[i]])

    testDataDict = {}
    for i in range(len(testCombinedUserIDList)):
        if (testCombinedUserIDList[i] not in testDataDict):
            testDataDict[testCombinedUserIDList[i]] = {}
        testDataDict[testCombinedUserIDList[i]][testCombinedISBNList[i]] = testCombinedRatingList[i]

    return [trainDataDict, testDataDict, trainBookDict]