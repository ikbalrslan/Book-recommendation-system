from collections import defaultdict

"""
Created on Mon Oct 22 15:29:44 2018
@author: ikbal
"""



def meanOfBookRating(trainBook):
    sumOfBookRatings = sum(trainBook.values())
    mean = sumOfBookRatings / len(trainBook.values())
    return mean

"""
correlation similarity of test user with train user
"""
def correlationSimilarity(testUserBooks, trainDataDict, trainBookDict):

    userAboveOfSim = defaultdict(int)
    userBelowOfSim = defaultdict(int)

    trainBookSum = 0
    for i in testUserBooks.keys(): #for each book of test user
        if i in trainBookDict.keys(): #if book in data train
            for j in trainBookDict[i].keys(): #loop for iterate ratings of the user that is readed the book.
                #print(j, testUserBooks[i], meanOfBookRating(trainBookDict[i]), trainDataDict[j][i], meanOfBookRating(trainBookDict[i]))
                # over calculations
                userAboveOfSim[j] += (testUserBooks[i] - meanOfBookRating(trainBookDict[i])) * (trainDataDict[j][i] - meanOfBookRating(trainBookDict[i]))
                userBelowOfSim[j] += ((trainDataDict[j][i] - meanOfBookRating(trainBookDict[i])) ** 2)

    """
    test user below calculations of similarity
    """
    testBookSum = 0
    for i in testUserBooks.keys():
        if i in trainBookDict.keys():
            testBookSum += ((testUserBooks[i] - meanOfBookRating(trainBookDict[i])) ** 2)
    rootOfTest = testBookSum ** (.5)

    for i in userBelowOfSim.keys():
        userBelowOfSim[i] = (userBelowOfSim[i] ** (.5))

    """
    result of similarity correlation formula
    """
    corrDict = defaultdict(int)
    for i in userAboveOfSim.keys():
        if (userAboveOfSim[i] != 0):
            correlationSimilarity = (userAboveOfSim[i] / (rootOfTest * userBelowOfSim[i]))
        else:
            correlationSimilarity = 0
        corrDict[i] = correlationSimilarity

    return corrDict