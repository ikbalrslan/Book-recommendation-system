from read import readFiles
import time
from calculationKNN import kNN,drawPlotOfAllScores
from constructDicts import constructDictMatrices
import pandas as pd
import numpy as np
from matplotlib.pylab import plt #load plot library
# indicate the output of plotting function is printed to the notebook

"""
Created on Mon Oct 22 15:29:44 2018
@author: ikbal
"""

"""
divide train data to 10 fold for CV and for each iteration take 1/10 to test data
and 9/10 to train data
"""
def kFoldCV(trainDataFrame,similarityFunc):
    size = len(trainDataFrame)
    Fold = 10
    part = size // Fold # divide train data to 10 fold for CV
    print("kFoldCV is processing, Please Wait...")
    lowestMeanOfErrors = 10
    choosenK = 0
    for i in range(1,30,2):
        sumOfErrors = 0
        print("k value: ", i)
        for j in range(0,Fold):
            if j != 9:
                test = trainDataFrame.iloc[part * j:part * (j+1), :] #take a part for each 1/10 from train data
                concat1 = trainDataFrame.iloc[:part * j, :]
                concat2 = trainDataFrame.iloc[part * (j+1):, :]
                frames = [concat1, concat2]
                train = pd.concat(frames)
            else:
                test = trainDataFrame.iloc[part * j:, :]  # take a part for each 1/10 from train data
                train = trainDataFrame.iloc[:part * j, :]  # take a part for each 1/10 from train data

            trainDataDict, testDataDict, trainBookDict = constructDictMatrices(train, test) #Dicts are creating here...

            threshold = 5
            k_value = i
            #print("Fold: ", j+1, " threshold:", threshold, "| kNN:", k_value)
            sumOfErrors += kNN(trainDataDict, testDataDict, trainBookDict, threshold, k_value, similarityFunc)[0]
            #print("----------------------------------------------------------------------------")
        meanOfErrors = sumOfErrors / Fold
        if(meanOfErrors <= lowestMeanOfErrors):
            lowestMeanOfErrors = meanOfErrors
            choosenK = i
        print("k:",i," mean of errors: ",meanOfErrors)
        print("-----------------------------------------------------------------------")
    print("choosen k_value: ",choosenK,lowestMeanOfErrors)

tstart = time.time()

trainDataFrame,testDataFrame = readFiles('BX-Users.csv','BX-Books.csv','BX-Book-Ratings-Train.csv',
                                         'BXBookRatingsTest.csv')
trainDataDict, testDataDict, trainBookDict = constructDictMatrices(trainDataFrame, testDataFrame)

cos = "cos"
corr = "corr"
adjCos = "adj"
"""
After N-Fold Cross Validation for N=10, the best error rate is found by these k values below:
For cosine similarity => k = 3 
For correlation based similarity => k = 3 
For adjusted cosine similarity => k = 13
"""
#kFoldCV(trainDataFrame,corr)

threshold = 5
k_value = 3
print("threshold:", threshold, "| kNN:", k_value)
meanOfMaes, meanOfWeightedMaes = kNN(trainDataDict, testDataDict, trainBookDict, threshold, k_value, cos) #last parameter is a similarity function name
print("non-Weight Error: ", meanOfMaes)
print("Weighted Error: ", meanOfWeightedMaes)
print("----------------------------------------------------------------------------")

"""
threshold = 5
corrList = []
adjList = []
cosList = []
wCorrList = []
wAdjList = []
wCosList = []
for i in range(1,26,2):
    k_value = i
    print("threshold:", threshold, "| kNN:", k_value)
    meanOfMaesCorr, meanOfWeightedMaesCorr = kNN(trainDataDict, testDataDict, trainBookDict, threshold, k_value, corr) #last parameter is a similarity function name
    corrList.append(meanOfMaesCorr)
    wCorrList.append(meanOfWeightedMaesCorr)
    meanOfMaesAdj, meanOfWeightedMaesAdj = kNN(trainDataDict, testDataDict, trainBookDict, threshold, k_value, adjCos)  # last parameter is a similarity function name
    adjList.append(meanOfMaesAdj)
    wAdjList.append(meanOfWeightedMaesAdj)
    meanOfMaesCos, meanOfWeightedMaesCos = kNN(trainDataDict, testDataDict, trainBookDict, threshold, k_value, cos)  # last parameter is a similarity function name
    cosList.append(meanOfMaesCos)
    wCosList.append(meanOfWeightedMaesCos)

drawPlotOfAllScores(corrList,wCorrList,adjList,wAdjList,cosList,wCosList)
"""
tend = time.time()
print("\nRuntime: " + str(tend-tstart))




